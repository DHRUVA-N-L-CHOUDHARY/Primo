package com.example.sammylivestreams.VidoeActivity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class VideoActivity {
}
class Videoactivty : AppCompatActivity(){
    private var mRtcEngine:RtcEngine? = null
    private var userRole = 0
    private var channelName:String? = null
            override fun onCreate(savedinstanceState:Bundle?){
                super.onCreate(savedInstanceState)
             setContentView(R.layout.video_activity)
                channelName = intent.getStringExtra("ChannelName"
                        userRole = intent.getIntExtra("UserRole ",  -1)
                initAgoraEngineAndJoinChannel()
            }
    fun initAgoraEngineAndJoinChannel(){
        initializeAgoraEngine()
    }

private fun initializeAgoraEngine(){
    try(
            mRtcEngine= RtcEngine.create(baseContext,APP ID ,mrtceventhandler)

}

}