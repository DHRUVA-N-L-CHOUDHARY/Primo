package com.example.sammylivestreams

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import java.util.jar.Manifest

class MainActivity : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestPermissions()

    }
     private fun requestPermission(){
         ActivityCompat.requestPermissions()(this, arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO).
     }

    fun onSubmit(view:View)  {
        val channelName = findViewById<View>(R.id.channel) as EditText
        val userRadioButton = findViewById<View>(R.id.radioGroup) as RadioGroup
       val checked = userRadioButton.checkedRadioButtonId
       val audienceButtoId = findViewById<View>(R.id.radioAudience) as RadioButton
        userRole = if (checked == audienceButtonId.id){
            0 }
        else{
            1
        }
        val intent = Intent(this,video_activity::class.java)
        intent.putExtra("ChannelName ",channelName.text.toString())
        intent.putExtra("UserRole",userRole)
        startActivity(Intent)

    }


}




